alert("I Love Flutter");
/*document.getElementById("user[login]").value="Guru759";*/
document.getElementById("user[email]").value="2878271548@qq.com";
document.getElementById("user[password]").value="***********";/*正常应为真正登录网站的密码*/ 



