# WeiboImageReverse
反查微博图片po主

来源 ：https://www.v2ex.com/t/388152

感谢 mysteri0uss 提供的代码 https://www.v2ex.com/t/388152?p=1#reply85

插件下载地址：https://chrome.google.com/webstore/detail/微博图片反查/egbnikffkpbahjabjhgblnfgbcnckjop
